import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import AdminLogin from "@/pages/AdminLogin";
import AdminDashboard from "@/pages/AdminDashboard";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import ProjectDetails from "./pages/ProjectDetails";
import { useEffect, useState } from "react";

function Router() {
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState<boolean | null>(null);

  useEffect(() => {
    // Check if admin session exists in cookie
    const adminSessionCookie = document.cookie
      .split("; ")
      .find((row) => row.startsWith("admin_session="));
    setIsAdminLoggedIn(!!adminSessionCookie);
  }, []);

  if (isAdminLoggedIn === null) {
    return <div className="min-h-screen bg-background flex items-center justify-center">Loading...</div>;
  }

  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/admin/login"} component={AdminLogin} />
      <Route path={"/dashboard"} component={AdminDashboard} />
      <Route path={"/project/:projectId"} component={ProjectDetails} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
